Add both xml files to the mod.
1 on left and 1 on right.
This way it will flicker different on 2 sides.

rampMini02 needs to be added to the the node of rampMini

rampMini.xml
rampMini02.xml
